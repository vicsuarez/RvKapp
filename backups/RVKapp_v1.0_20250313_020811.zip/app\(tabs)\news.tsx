import React from 'react';
import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity, SafeAreaView, StatusBar, Platform } from 'react-native';
import { Stack } from 'expo-router';
import { StatusBar as ExpoStatusBar } from 'expo-status-bar';

export default function NewsPage() {
  // Mock news data
  const newsItems = [
    {
      id: 1,
      title: "New Scarlet & Violet Set Announced",
      date: "March 10, 2025",
      excerpt: "The Pokémon Company has announced the next expansion for the Scarlet & Violet series, featuring new Paradox Pokémon.",
      image: { uri: 'https://via.placeholder.com/800x400' },
    },
    {
      id: 2,
      title: "Championship Series Dates Revealed",
      date: "March 8, 2025",
      excerpt: "The dates for the upcoming Pokémon TCG Championship Series have been announced, with events scheduled across North America, Europe, and Japan.",
      image: { uri: 'https://via.placeholder.com/800x400' },
    },
    {
      id: 3,
      title: "Market Watch: Charizard Prices Soaring",
      date: "March 5, 2025",
      excerpt: "Prices for vintage and modern Charizard cards continue to rise as collectors and investors compete for rare variants.",
      image: { uri: 'https://via.placeholder.com/800x400' },
    },
    {
      id: 4,
      title: "New Promo Cards Available at Select Retailers",
      date: "March 1, 2025",
      excerpt: "Special promotional cards will be available at participating retailers with purchase of select Pokémon TCG products.",
      image: { uri: 'https://via.placeholder.com/800x400' },
    },
  ];

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="dark-content" backgroundColor="#fff" />
      <ExpoStatusBar style="dark" />
      <Stack.Screen options={{ headerShown: false }} />
      
      <View style={styles.header}>
        <Text style={styles.headerTitle}>News</Text>
      </View>

      <ScrollView style={styles.content}>
        <View style={styles.featuredNewsContainer}>
          <Image 
            source={{ uri: 'https://via.placeholder.com/800x400' }} 
            style={styles.featuredImage} 
          />
          <View style={styles.featuredOverlay}>
            <Text style={styles.featuredTag}>FEATURED</Text>
            <Text style={styles.featuredTitle}>Pokémon TCG Live Global Launch</Text>
            <Text style={styles.featuredDate}>March 12, 2025</Text>
          </View>
        </View>

        <Text style={styles.sectionTitle}>Latest News</Text>

        {newsItems.map((item) => (
          <TouchableOpacity key={item.id} style={styles.newsItem}>
            <Image source={item.image} style={styles.newsImage} />
            <View style={styles.newsContent}>
              <Text style={styles.newsTitle}>{item.title}</Text>
              <Text style={styles.newsDate}>{item.date}</Text>
              <Text style={styles.newsExcerpt} numberOfLines={2}>
                {item.excerpt}
              </Text>
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#fff',
    paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight : 0,
  },
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
    backgroundColor: '#fff',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  content: {
    flex: 1,
  },
  featuredNewsContainer: {
    position: 'relative',
    height: 200,
    marginBottom: 20,
  },
  featuredImage: {
    width: '100%',
    height: '100%',
  },
  featuredOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: 16,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  featuredTag: {
    color: '#fff',
    backgroundColor: '#007AFF',
    alignSelf: 'flex-start',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
    fontSize: 12,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  featuredTitle: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  featuredDate: {
    color: 'rgba(255, 255, 255, 0.8)',
    fontSize: 12,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginHorizontal: 16,
    marginBottom: 12,
  },
  newsItem: {
    flexDirection: 'row',
    marginHorizontal: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#eee',
    borderRadius: 8,
    overflow: 'hidden',
  },
  newsImage: {
    width: 100,
    height: 100,
  },
  newsContent: {
    flex: 1,
    padding: 12,
  },
  newsTitle: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  newsDate: {
    fontSize: 12,
    color: '#777',
    marginBottom: 6,
  },
  newsExcerpt: {
    fontSize: 14,
    color: '#333',
    lineHeight: 20,
  },
}); 