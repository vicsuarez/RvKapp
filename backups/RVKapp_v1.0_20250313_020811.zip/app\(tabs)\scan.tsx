import React from 'react';
import { View, StyleSheet, SafeAreaView, StatusBar, Platform } from 'react-native';
import { Stack } from 'expo-router';
import ScanInterface from '@/app/components/ScanInterface';
import { StatusBar as ExpoStatusBar } from 'expo-status-bar';

export default function ScanPage() {
  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="light-content" backgroundColor="#000" />
      <ExpoStatusBar style="light" />
      <Stack.Screen options={{ headerShown: false }} />
      <ScanInterface />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#000',
    paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight : 0,
  },
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
}); 