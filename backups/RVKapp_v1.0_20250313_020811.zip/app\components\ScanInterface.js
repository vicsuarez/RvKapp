import React, { useState, useRef, useCallback } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { CameraView } from 'expo-camera';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';

export default function ScanInterface() {
  const router = useRouter();
  const [isScanning, setIsScanning] = useState(true);
  const [isRecognized, setIsRecognized] = useState(false);
  const [scanResult, setScanResult] = useState(null);
  
  const cameraRef = useRef(null);
  const isProcessingRef = useRef(false);

  // Handle camera ready event
  const handleCameraReady = useCallback(() => {
    console.log('Camera is ready');
  }, []);

  // Debounced button handlers to prevent multiple rapid presses
  const handleButtonPress = useCallback((action) => {
    if (isProcessingRef.current) return;

    isProcessingRef.current = true;
    action();

    // Reset after a short delay
    setTimeout(() => {
      isProcessingRef.current = false;
    }, 500);
  }, []);

  const handleCapture = useCallback(() => {
    handleButtonPress(() => {
      console.log('Capturing image');
      // Simulate card recognition after 1 second
      setIsRecognized(true);
      setTimeout(() => {
        setIsRecognized(false);
        // Mock scan result
        setScanResult({
          id: 1,
          name: "Charizard (Rare)",
          set: "Base Set",
          number: "4/102",
          price: 120.50,
          image: { uri: 'https://via.placeholder.com/215x300' },
        });
      }, 1000);
    });
  }, [handleButtonPress]);

  const resetScan = useCallback(() => {
    handleButtonPress(() => {
      setScanResult(null);
    });
  }, [handleButtonPress]);

  const exitScan = useCallback(() => {
    handleButtonPress(() => {
      console.log('Exiting scan');
      router.back();
    });
  }, [router, handleButtonPress]);

  return (
    <View style={styles.container}>
      {/* Close button */}
      <TouchableOpacity style={styles.closeButton} onPress={exitScan}>
        <Ionicons name="close" size={24} color="white" />
      </TouchableOpacity>

      {/* Camera viewfinder */}
      <View style={styles.viewfinderContainer}>
        {!scanResult ? (
          <>
            {/* Card scanning area with border */}
            <View style={styles.scanArea}>
              {isRecognized && <View style={styles.recognizedOverlay} />}

              {/* Camera feed */}
              {isScanning ? (
                <View style={styles.camera}>
                  <CameraView
                    style={{flex: 1}}
                    ref={cameraRef}
                    onCameraReady={handleCameraReady}
                  />
                </View>
              ) : (
                <View style={styles.placeholderContainer}>
                  <Ionicons name="camera" size={48} color="rgba(255, 255, 255, 0.7)" />
                  <Text style={styles.placeholderText}>Position your card within the frame</Text>
                </View>
              )}
            </View>

            {/* PRO badge */}
            <View style={styles.proBadgeContainer}>
              <View style={styles.proBadge}>
                <Text style={styles.proBadgeText}>PRO</Text>
                <Text style={styles.proBadgeSubtext}>34 scans remaining.</Text>
              </View>
              <Text style={styles.tapText}>Tap here to get unlimited scans.</Text>
            </View>
          </>
        ) : (
          <View style={styles.resultContainer}>
            <Image 
              source={scanResult.image} 
              style={styles.resultImage}
              resizeMode="cover"
            />
          </View>
        )}
      </View>

      {/* Bottom action buttons */}
      <View style={styles.actionButtons}>
        <TouchableOpacity style={styles.secondaryButton}>
          <Ionicons name="image" size={24} color="white" />
        </TouchableOpacity>

        {!scanResult ? (
          <TouchableOpacity
            style={styles.primaryButton}
            onPress={handleCapture}
            disabled={isRecognized}
          >
            <Ionicons name="camera" size={32} color="black" />
          </TouchableOpacity>
        ) : (
          <TouchableOpacity
            style={styles.primaryButton}
            onPress={resetScan}
          >
            <Ionicons name="camera" size={32} color="black" />
          </TouchableOpacity>
        )}

        <TouchableOpacity
          style={[
            styles.secondaryButton,
            scanResult ? styles.activeButton : {}
          ]}
          disabled={!scanResult}
        >
          <Ionicons name="checkmark" size={24} color="white" />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'black',
    zIndex: 50,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  closeButton: {
    position: 'absolute',
    top: 16,
    left: 16,
    zIndex: 10,
    padding: 8,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    borderRadius: 20,
  },
  viewfinderContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
  },
  scanArea: {
    position: 'relative',
    aspectRatio: 2/3,
    width: '80%',
    maxWidth: 280,
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.7)',
    borderRadius: 8,
    overflow: 'hidden',
  },
  recognizedOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 128, 255, 0.2)',
    opacity: 0.8,
    zIndex: 5,
  },
  camera: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  placeholderContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
  },
  placeholderText: {
    color: 'rgba(255, 255, 255, 0.7)',
    textAlign: 'center',
    marginTop: 8,
    fontSize: 14,
  },
  proBadgeContainer: {
    position: 'absolute',
    bottom: 96,
    alignItems: 'center',
  },
  proBadge: {
    backgroundColor: '#F59E0B',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 4,
    flexDirection: 'row',
    alignItems: 'center',
  },
  proBadgeText: {
    color: 'black',
    fontWeight: 'bold',
    marginRight: 8,
    fontSize: 14,
  },
  proBadgeSubtext: {
    color: 'black',
    fontSize: 12,
  },
  tapText: {
    color: 'white',
    fontSize: 12,
    marginTop: 4,
  },
  resultContainer: {
    position: 'relative',
    aspectRatio: 2/3,
    width: '80%',
    maxWidth: 280,
    borderRadius: 8,
    overflow: 'hidden',
  },
  resultImage: {
    width: '100%',
    height: '100%',
  },
  actionButtons: {
    position: 'absolute',
    bottom: 16,
    left: 0,
    right: 0,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    paddingHorizontal: 16,
  },
  secondaryButton: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.5)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  primaryButton: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
  },
  activeButton: {
    backgroundColor: '#171717',
    borderColor: '#171717',
  },
  text: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 12,
  },
  subText: {
    color: 'rgba(255, 255, 255, 0.7)',
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 24,
  },
  buttonText: {
    color: 'black',
    fontSize: 16,
    fontWeight: '600',
  },
  secondaryButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '500',
  },
}); 